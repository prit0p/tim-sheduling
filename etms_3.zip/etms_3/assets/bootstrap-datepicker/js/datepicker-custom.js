// =========showing today's date always

// $(function () {
//   $("#datepicker").datepicker({ 
//         autoclose: true, 
//         todayHighlight: true
//   }).datepicker('update', new Date());
// });


// =========empty input field
$(function () {
  $("#datepicker").datepicker({ 
        autoclose: true, 
        todayHighlight: true
  });
});

$(function () {
  $("#datepicker2").datepicker({ 
        autoclose: true, 
        todayHighlight: true
  });
});

$(function () {
  $("#datepicker3").datepicker({ 
        autoclose: true, 
        todayHighlight: true
  });
});

$(function () {
  $("#datepicker4").datepicker({ 
        autoclose: true, 
        todayHighlight: true
  });
});