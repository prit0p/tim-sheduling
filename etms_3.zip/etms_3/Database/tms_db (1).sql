-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 14, 2023 at 03:31 AM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tms_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance_info`
--

DROP TABLE IF EXISTS `attendance_info`;
CREATE TABLE IF NOT EXISTS `attendance_info` (
  `aten_id` int(20) NOT NULL AUTO_INCREMENT,
  `atn_user_id` int(20) NOT NULL,
  `in_time` datetime DEFAULT NULL,
  `out_time` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `total_duration` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`aten_id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `attendance_info`
--

INSERT INTO `attendance_info` (`aten_id`, `atn_user_id`, `in_time`, `out_time`, `total_duration`) VALUES
(34, 1, '2023-05-10 16:10:18', '2023-05-10 16:10:44', '00:00:26'),
(8, 1, '2023-03-18 13:17:21', '2023-03-18 13:17:31', '00:00:10'),
(5, 1, '2023-02-04 13:47:39', '2023-02-04 13:47:54', '00:00:15'),
(7, 1, '2023-03-18 13:17:02', '2023-03-18 13:17:16', '00:00:14'),
(11, 1, '2023-05-06 16:47:08', '2023-05-06 16:51:24', '00:04:16'),
(16, 37, '2023-05-06 16:52:42', '2023-05-06 16:52:44', '00:00:02'),
(17, 37, '2023-05-06 16:52:45', '2023-05-06 16:55:03', '00:02:18'),
(21, 1, '2023-05-06 21:40:20', '2023-05-06 21:41:33', '00:01:13'),
(33, 1, '2023-05-07 17:57:39', '2023-05-07 17:59:10', '00:01:31'),
(25, 1, '2023-05-06 19:29:01', '2023-05-06 21:59:01', '00:01:03'),
(31, 1, '2023-05-07 18:29:25', '2023-05-07 18:29:28', '00:00:03'),
(32, 1, '2023-05-07 16:01:20', '2023-05-07 16:01:24', '00:00:04');

-- --------------------------------------------------------

--
-- Table structure for table `task_info`
--

DROP TABLE IF EXISTS `task_info`;
CREATE TABLE IF NOT EXISTS `task_info` (
  `task_id` int(50) NOT NULL AUTO_INCREMENT,
  `t_title` varchar(120) NOT NULL,
  `t_description` text,
  `t_start_time` datetime DEFAULT NULL,
  `t_end_time` datetime DEFAULT NULL,
  `t_user_id` int(20) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0 = incomplete, 1 = In progress, 2 = complete',
  `t_created_on` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`task_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `task_info`
--

INSERT INTO `task_info` (`task_id`, `t_title`, `t_description`, `t_start_time`, `t_end_time`, `t_user_id`, `status`, `t_created_on`) VALUES
(4, 'Create database table of TMS', 'use primary key in user/emplyee/admin Id', '2023-03-30 12:00:00', '2023-03-31 18:00:00', 37, 2, '2023-03-31 06:57:37'),
(5, 'add emplyee detail', '', '2023-03-07 08:00:00', '2023-03-30 12:00:00', 34, 0, '2023-03-31 07:26:00'),
(7, 'create design', 'at least 1 or 2 page', '2023-03-31 12:00:00', '2023-06-01 08:00:00', 31, 1, '2023-05-04 18:55:08'),
(8, 'attach coding in ppt', '', '2023-06-02 16:00:00', '2023-05-02 17:00:00', 33, 1, '2023-05-04 18:55:47'),
(9, 'project review - 1', 'present only ppt', '2023-03-22 16:30:00', '2023-04-26 18:00:00', 34, 0, '2023-05-04 18:57:21'),
(10, 'final testing of project', '', '2023-03-30 05:00:00', '2023-04-04 16:00:00', 32, 0, '2023-05-04 18:58:44'),
(11, 'prepare and show project report parallely after each phase', '', '2023-05-05 12:00:00', '2023-05-05 16:00:00', 37, 2, '2023-05-04 19:00:35');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

DROP TABLE IF EXISTS `tbl_admin`;
CREATE TABLE IF NOT EXISTS `tbl_admin` (
  `user_id` int(20) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(120) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `temp_password` varchar(100) DEFAULT NULL,
  `user_role` int(10) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 COMMENT='2';

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`user_id`, `fullname`, `username`, `email`, `password`, `temp_password`, `user_role`) VALUES
(1, 'Admin', 'admin', 'admin@gmail.com', '0192023a7bbd73250516f069df18b500', NULL, 1),
(34, 'Devanshu More', 'devanshu', 'devanshumore@gmail.com', '30c20a73dc227e539f4669e30250df9f', '9417187', 2),
(33, 'Dhruv Savaliya', 'dhruv', 'dhruvsavaliya@gmail.com', 'c7927df3404f3da94ced430eda2c8703', '2477506', 2),
(32, 'Dev Patel', 'dev', 'devpatel@gmail.com', '10032586bc62852d2a7ed121da58d05f', '', 2),
(31, 'Bhargav Vaghasiya', 'bhargav', 'bhargavvaghasiya@gmail.com', '1a3d4d5b8b0e5f3eaeedd0b1ff81b285', '', 2),
(36, 'Prit Bhatt', 'prit', 'pritbhatt@gmail.com', '0d9b2ca576784398e52bea20c38a375b', '', 2),
(37, 'Parth Mistry', 'parth', 'iamparthmistry@gmail.com', '1592f4a6f03dfdf4dca29de2a7874507', '', 2);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
